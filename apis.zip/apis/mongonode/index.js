require('dotenv').config(); // Cargar las variables de entorno desde .env

const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');

const app = express();


app.use(bodyParser.json());

// Conexión a MongoDB usando la variable de entorno
mongoose.connect(process.env.MONGO_URI, {
    useUnifiedTopology: true
})
.then(() => console.log("Conexión a MongoDB establecida"))
.catch((err) => console.error("Error conectándose a MongoDB:", err));

// Definir el esquema para los datos de pago
const pagoSchema = new mongoose.Schema({
    MetodoPago: { type: String, required: true },
    NumeroTarjeta: { type: String, required: true },
    Correo: { type: String, required: true },
    CodigoSeguridad: { type: String, required: true },
    Identificacion: { type: String, required: true },
    NombreCompleto: { type: String, required: true },
    Telefono: { type: String, required: true },
    Direccion: { type: String, required: true },
    CodigoLealtad: { type: String },
    Total: { type: String, required: true },
    FechaPago: { type: Date, required: true }
});


const Pago = mongoose.model('Pago', pagoSchema, 'Pagos');

// Ruta POST para crear un pago
app.post('/api/pagos', async (req, res) => {
    try {
        
        const nuevoPago = new Pago(req.body);

       
        await nuevoPago.save();

       
        res.status(201).json(nuevoPago);
    } catch (error) {
        
        res.status(400).json({ error: error.message });
    }
});


const port = process.env.PORT || 3000;
app.listen(port, () => {
    console.log(`Servidor funcionando en el puerto ${port}`);
});
